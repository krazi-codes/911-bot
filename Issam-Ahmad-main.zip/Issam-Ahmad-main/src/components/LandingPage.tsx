import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { signInWithGoogle } from '../lib/firebase';
import { Bot, ShieldAlert, Zap, Clock, ChevronRight } from 'lucide-react';

export default function LandingPage() {
  const { user } = useAuth();
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      await signInWithGoogle();
    } catch (error) {
      console.error("Login failed", error);
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-red-500/30 relative overflow-hidden flex flex-col p-6 sm:p-8">
      {/* Atmospheric Background Glows */}
      <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-red-600/10 blur-[140px] rounded-full pointer-events-none" />
      <div className="absolute -bottom-48 -left-24 w-[500px] h-[500px] bg-blue-600/5 blur-[120px] rounded-full pointer-events-none" />

      {/* Navigation */}
      <nav className="relative z-10 flex justify-between items-center mb-16 max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-red-600 flex items-center justify-center rounded-lg shadow-[0_0_20px_rgba(220,38,38,0.4)]">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold tracking-tighter uppercase sm:text-xl">Rescue Remix</span>
        </div>
        <div className="flex items-center gap-4 sm:gap-8">
          <div className="hidden sm:flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-[11px] uppercase tracking-widest text-zinc-500 font-semibold">Neural Network Active</span>
          </div>
          <button
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="px-6 py-2 bg-white/5 border border-white/10 rounded-full text-xs font-semibold hover:bg-white/10 transition-colors uppercase tracking-widest disabled:opacity-50"
          >
            Terminal Access
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="relative z-10 flex-1 max-w-7xl mx-auto w-full text-white">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 flex flex-col justify-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-6 w-fit">
              <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse shadow-[0_0_10px_rgba(220,38,38,0.6)]" />
              Next-Gen Emergency Dispatch
            </div>
            <h1 className="text-[48px] sm:text-[64px] lg:text-[84px] font-extrabold leading-[0.9] tracking-tighter mb-6 uppercase">
              First responder intelligence at <br/><span className="text-red-600">machine speed.</span>
            </h1>
            <p className="text-zinc-400 text-lg max-w-lg mb-10 leading-relaxed">
              Autonomously triage incoming 911 calls, extract critical entity data, and dispatch appropriate resources instantly. Built for the modern PSAP.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-4">
              <button
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="w-full sm:w-auto py-4 px-8 bg-white text-black font-black uppercase tracking-widest rounded-xl hover:bg-zinc-200 transition-all disabled:opacity-75 disabled:cursor-wait flex items-center justify-center gap-2 text-sm"
              >
                {isLoggingIn ? 'Authenticating...' : 'Initialize Uplink'}
                {!isLoggingIn && <ChevronRight className="w-4 h-4" />}
              </button>
              <a
                href="#features"
                className="w-full sm:w-auto py-4 px-8 bg-zinc-800/50 border border-zinc-700 text-zinc-300 font-bold flex items-center justify-center gap-3 rounded-xl hover:bg-zinc-800 transition-all uppercase tracking-widest text-sm"
              >
                View Capabilities
              </a>
            </div>
          </div>

          {/* Abstract Hero Visual */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <div className="bg-zinc-900/80 border border-white/10 rounded-[32px] p-8 sm:p-10 backdrop-blur-xl shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="animate-pulse w-3 h-3 bg-red-600 rounded-full shadow-[0_0_10px_rgba(220,38,38,0.6)]" />
                  <span className="text-xs font-bold uppercase tracking-widest font-mono text-zinc-400">INCOMING INCIDENT // #84092</span>
                </div>
                <span className="text-[10px] sm:text-xs font-mono text-zinc-500 uppercase tracking-widest">00:00:14</span>
              </div>
              <div className="space-y-4 font-mono text-sm">
                <div className="flex gap-4">
                  <span className="text-zinc-600 uppercase text-xs pt-0.5">Transcribing</span>
                  <p className="text-zinc-300 leading-relaxed text-xs sm:text-sm">"...yes, there is a two-car collision at the intersection of 5th and Main. Someone looks trapped."</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 p-4 bg-black/40 border border-white/5 rounded-xl">
                  <span className="text-red-500 font-bold uppercase text-xs tracking-widest whitespace-nowrap">&gt; AI PARSE</span>
                  <div className="space-y-2 text-xs sm:text-sm">
                    <p><span className="text-zinc-500 uppercase">Type:</span> <span className="text-white font-semibold flex items-center justify-between">Vehicle Collision</span></p>
                    <p><span className="text-zinc-500 uppercase">Loc:</span> <span className="text-white font-semibold">5th Ave & Main St</span></p>
                    <p><span className="text-zinc-500 uppercase">Status:</span> <span className="text-red-500 font-semibold uppercase animate-pulse">Entrapment Reported</span></p>
                  </div>
                </div>
                <div className="flex gap-4 pt-2">
                  <span className="text-green-500 font-bold uppercase text-xs tracking-widest whitespace-nowrap pt-0.5">&gt; ACTION</span>
                  <p className="text-zinc-300 text-xs sm:text-sm">Dispatching Fire Unit 4, EMS Unit 12.</p>
                </div>
              </div>

              <div className="flex items-center gap-4 my-6">
                <div className="h-[1px] flex-1 bg-white/5"></div>
                <span className="text-[10px] uppercase tracking-widest text-zinc-600 font-bold">Sync</span>
                <div className="h-[1px] flex-1 bg-white/5"></div>
              </div>

              <button 
                onClick={() => alert('This app is fully GitHub compatible! To send it to your GitHub account, click the Settings menu (gear icon) in the top right of AI Studio and select "Export to GitHub".')}
                className="w-full py-3 sm:py-4 bg-zinc-800/50 border border-zinc-700 text-zinc-300 font-bold flex items-center justify-center gap-3 rounded-xl hover:bg-zinc-800 transition-all uppercase tracking-widest text-[10px] sm:text-xs"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.042-1.416-4.042-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                </svg>
                Sync Config to GitHub
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Features */}
      <section id="features" className="relative z-10 border-t border-white/5 pt-16">
        <div className="max-w-7xl mx-auto px-0 py-24">
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-2 uppercase tracking-tight">Unprecedented Awareness</h2>
            <p className="text-zinc-500 text-sm max-w-xl">Our machine learning models are fine-tuned specifically for the noise and urgency of real-world emergency channels.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-8 bg-zinc-900/50 border border-zinc-800 rounded-2xl flex flex-col backdrop-blur-md">
              <Zap className="w-8 h-8 text-red-500 mb-6" />
              <div className="text-white text-xl font-bold mb-2 uppercase tracking-tight">Instant Triage</div>
              <div className="text-xs uppercase tracking-widest text-zinc-500 leading-relaxed">
                Automatically prioritize incoming requests based on intent extraction, ensuring critical incidents jump the queue.
              </div>
            </div>
            
            <div className="p-8 bg-zinc-900/50 border border-zinc-800 rounded-2xl flex flex-col backdrop-blur-md">
              <ShieldAlert className="w-8 h-8 text-red-500 mb-6" />
              <div className="text-white text-xl font-bold mb-2 uppercase tracking-tight">Contextual Safety</div>
              <div className="text-xs uppercase tracking-widest text-zinc-500 leading-relaxed">
                Cross-reference caller history and active incidents in the area to provide responders with critical warning intelligence.
              </div>
            </div>
            
            <div className="p-8 bg-zinc-900/50 border border-zinc-800 rounded-2xl flex flex-col backdrop-blur-md">
              <Clock className="w-8 h-8 text-red-500 mb-6" />
              <div className="text-white text-xl font-bold mb-2 uppercase tracking-tight">Zero-Latency Dispatch</div>
              <div className="text-xs uppercase tracking-widest text-zinc-500 leading-relaxed">
                Reduce response times by pre-filling CAD systems via API the moment actionable entities are extracted.
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 pt-8 pb-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-start md:items-end gap-12 max-w-7xl mx-auto w-full mt-8">
        <div className="flex gap-12">
          <div className="flex flex-col gap-1">
            <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">System Build</span>
            <span className="text-xs font-mono text-zinc-300">v4.0.2-RELEASE-SENTINEL</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Encrypted Nodes</span>
            <span className="text-xs font-mono text-zinc-300">FRA, ICN, JFK, SFO</span>
          </div>
        </div>
        <div className="md:text-right">
          <p className="text-[10px] text-zinc-600 uppercase tracking-widest max-w-xs leading-relaxed">
            This terminal is intended for authorized law enforcement use only. All activities are monitored by SENTINEL AI. &copy; 2026.
          </p>
        </div>
      </footer>
    </div>
  );
}
