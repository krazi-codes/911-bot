import React, { useState, useCallback } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { logOut } from '../lib/firebase';
import { LogOut, Shield, Activity, PhoneCall, Bot, Mic, MicOff } from 'lucide-react';
import { useConversation } from '@11labs/react';

export default function Dashboard() {
  const { user } = useAuth();
  const conversation = useConversation();
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  const toggleVoiceSession = useCallback(async () => {
    setErrorStatus(null);
    if (conversation.status === 'connected') {
      await conversation.endSession();
    } else {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        
        await conversation.startSession({
          agentId: import.meta.env.VITE_ELEVENLABS_AGENT_ID || '', // Configured in .env
        });
      } catch (err: any) {
        console.error("Failed to start voice session:", err);
        setErrorStatus(err.message || "Could not connect to voice agent. Check your AGENT_ID and microphone permissions.");
      }
    }
  }, [conversation]);

  if (!user) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-neutral-50 font-sans">
      <header className="bg-white border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-red-600 text-white p-2 rounded-lg">
              <Bot className="w-5 h-5" />
            </div>
            <span className="font-semibold text-lg tracking-tight text-neutral-900 uppercase">
              Rescue Remix
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              {user.photoURL && (
                <img 
                  src={user.photoURL} 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full border border-neutral-200"
                />
              )}
              <span className="text-sm font-medium text-neutral-700 hidden sm:block">
                {user.displayName || user.email}
              </span>
            </div>
            <button
              onClick={logOut}
              className="flex items-center justify-center p-2 text-neutral-500 hover:text-neutral-700 hover:bg-neutral-100 rounded-md transition-colors"
              title="Log out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-neutral-900">Operator Dashboard</h1>
          <p className="text-neutral-500 mt-1">Monitor active calls and AI analysis</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-sm flex flex-col">
            <div className="flex items-center gap-3 mb-2">
              <Activity className="w-5 h-5 text-emerald-500" />
              <h3 className="font-semibold text-neutral-700">System Status</h3>
            </div>
            <p className="text-3xl font-bold text-neutral-900 mt-auto">Operational</p>
            <p className="text-sm text-emerald-600 mt-1">All AI modules online</p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-sm flex flex-col">
            <div className="flex items-center gap-3 mb-2">
              <PhoneCall className="w-5 h-5 text-blue-500" />
              <h3 className="font-semibold text-neutral-700">Active Calls</h3>
            </div>
            <p className="text-3xl font-bold text-neutral-900 mt-auto">0</p>
            <p className="text-sm text-neutral-500 mt-1">Awaiting incoming calls</p>
          </div>

          <div className="bg-white p-6 rounded-xl border border-neutral-200 shadow-sm flex flex-col">
            <div className="flex items-center gap-3 mb-2">
              <Shield className="w-5 h-5 text-amber-500" />
              <h3 className="font-semibold text-neutral-700">Threat Alerts</h3>
            </div>
            <p className="text-3xl font-bold text-neutral-900 mt-auto">None</p>
            <p className="text-sm text-neutral-500 mt-1">No critical anomalies</p>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-neutral-200 shadow-sm overflow-hidden min-h-[400px] flex items-center justify-center p-8">
          <div className="text-center max-w-md w-full">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 transition-all duration-300 ${conversation.status === 'connected' ? 'bg-red-100 shadow-[0_0_30px_rgba(220,38,38,0.3)]' : 'bg-neutral-100'}`}>
              <Bot className={`w-10 h-10 ${conversation.status === 'connected' ? 'text-red-600' : 'text-neutral-400'}`} />
            </div>
            <h2 className="text-2xl font-bold text-neutral-900 mb-2">Voice Dispatch AI</h2>
            <p className="text-neutral-500 mb-8">
              Press the button below to initialize the voice-compatible dispatch assistant powered by ElevenLabs.
            </p>

            {errorStatus && (
              <div className="mb-6 p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">
                {errorStatus}
              </div>
            )}

            <button
              onClick={toggleVoiceSession}
              disabled={conversation.status === 'connecting'}
              className={`w-full py-4 px-6 rounded-xl font-bold flex items-center justify-center gap-3 transition-colors disabled:opacity-50
                ${conversation.status === 'connected' 
                  ? 'bg-neutral-900 text-white hover:bg-neutral-800' 
                  : 'bg-red-600 text-white hover:bg-red-700'}`}
            >
              {conversation.status === 'connected' ? (
                <>
                  <MicOff className="w-5 h-5" />
                  End Voice Session
                </>
              ) : (
                <>
                  <Mic className="w-5 h-5" />
                  {conversation.status === 'connecting' ? 'Connecting...' : 'Start Voice Session'}
                </>
              )}
            </button>
            
            {conversation.status === 'connected' && (
              <div className="mt-8 flex items-center justify-center gap-2 text-sm text-red-600 font-medium">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
                Listening & Speaking...
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
